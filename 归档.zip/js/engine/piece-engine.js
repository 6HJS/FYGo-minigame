function createPiece(color, type = 'normal', dir = null, id = null, extra = null) {
  return { id, color, type, dir, ...(extra || {}) };
}

function getPieceDef(pieceMap, type) {
  return pieceMap[type] || pieceMap.normal;
}

function getOffsetsByDir(offsetsByDir, dir) {
  if (!offsetsByDir) return [];
  return offsetsByDir[dir] || offsetsByDir.U || [];
}

function getAreaByOffsets(scene, row, col, offsets, options = {}) {
  const result = [];
  const seen = new Set();
  const allowOutsideCurrentShape = !!options.allowOutsideCurrentShape;

  for (const [dr, dc] of offsets) {
    const nr = row + dr;
    const nc = col + dc;

    if (allowOutsideCurrentShape) {
      if (!scene.isInside(nr, nc)) continue;
    } else if (!scene.isBoardShapeCell(nr, nc)) {
      continue;
    }

    const key = `${nr},${nc}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push([nr, nc]);
  }

  return result;
}

function handleMoveForward(scene, row, col, piece, pieceDef) {
  const dirMap = scene.DIRS;
  const move = dirMap[piece.dir];
  if (!move) return null;

  const nr = row + move.dr;
  const nc = col + move.dc;

  if (!scene.isPlayablePoint(nr, nc)) {
    const fallbackType = pieceDef.behavior.transformOnBlocked || 'normal';
    scene.board[row][col] = createPiece(piece.color, fallbackType, null, piece.id);
    return {
      moved: false,
      transformed: true
    };
  }

  const occupant = scene.board[nr][nc];
  if (scene.isPiece(occupant)) {
    if (pieceDef.behavior.killOccupant) {
      const isEnemy = occupant.color !== piece.color;
      scene.resolvePieceRemovalAt(nr, nc, {
        reason: 'special',
        allowRebirth: true,
        scoreForColor: isEnemy ? piece.color : null
      });
    } else {
      const fallbackType = pieceDef.behavior.transformOnBlocked || 'normal';
      scene.board[row][col] = createPiece(piece.color, fallbackType, null, piece.id);
      return {
        moved: false,
        transformed: true,
        blockedByEnemy: occupant.color !== piece.color,
        blockedByAlly: occupant.color === piece.color
      };
    }
  }

  scene.board[nr][nc] = createPiece(piece.color, piece.type, piece.dir, piece.id);
  scene.board[row][col] = null;
  scene.lastMove = { row: nr, col: nc };

  // 骑兵冲锋后，立刻结算因“挪位”导致的提子。
  // 规则：
  // 1) 冲死敌子，计入骑兵方提子；
  // 2) 冲死己子，不计提子；
  // 3) 挪位后造成其他棋子无气，立即按骑兵行动方结算；
  // 4) 若因此连带紧死己方棋子，也只移除，不给对方记提子。
  if (pieceDef.behavior.killOccupant && typeof scene.stabilizeBoardState === 'function') {
    scene.stabilizeBoardState(scene.board, {
      collectCounted: true,
      creditColor: piece.color,
      applyScore: true
    });
  }

  return {
    moved: true,
    transformed: false
  };
}

function handleBlastArea(scene, row, col, piece, pieceDef) {
  const rule = pieceDef.behavior;
  GameGlobal.musicManager.playExplosion(); // 播放爆炸音效

  if (rule.disableIfEnemyAdjacent && scene.hasEnemyAdjacent(row, col, piece.color)) {
    const downgrade = rule.degradeTo || 'normal';
    scene.board[row][col] = createPiece(piece.color, downgrade, null, piece.id);
    return {
      exploded: [],
      triggeredCount: 0,
      disabledCount: 1,
      destroyedCellsCount: 0
    };
  }

  const offsets = getOffsetsByDir(rule.offsetsByDir, piece.dir);
  const area = getAreaByOffsets(scene, row, col, offsets);
  const destroyArea = rule.destroyCells
    ? (rule.destroyOnlySelfCell ? [[row, col]] : area)
    : [];
  const destroyKeys = new Set(destroyArea.map(([r, c]) => `${r},${c}`));

  const exploded = [];
  let destroyedCellsCount = 0;
  const blockedRebirthKeys = new Set(area.map(([r, c]) => `${r},${c}`));

  for (const [r, c] of area) {
    if (scene.isPiece(scene.board[r][c])) {
      exploded.push([r, c]);
      scene.resolvePieceRemovalAt(r, c, {
        reason: 'special',
        allowRebirth: true,
        blockedRebirthKeys,
        scoreByVictimOpposition: true
      });
    }

    if (destroyKeys.has(`${r},${c}`)) {
      if (scene.board[r][c] !== scene.DESTROYED) {
        destroyedCellsCount++;
      }
      scene.board[r][c] = scene.DESTROYED;
    } else {
      scene.board[r][c] = null;
    }
  }

  scene.lastMove = { row, col };

  return {
    exploded,
    triggeredCount: 1,
    disabledCount: 0,
    destroyedCellsCount
  };
}

function handleRaiseFrontCells(scene, row, col, piece, pieceDef) {
  const rule = pieceDef.behavior || {};
  const offsets = getOffsetsByDir(rule.offsetsByDir, piece.dir);
  const area = getAreaByOffsets(scene, row, col, offsets, { allowOutsideCurrentShape: true });

  let createdCellsCount = 0;

  for (const [r, c] of area) {
    if (scene.restorePlayableCell(r, c)) {
      createdCellsCount += 1;
    }
  }

  const downgrade = rule.degradeTo || 'normal';
  scene.board[row][col] = createPiece(piece.color, downgrade, null, piece.id);
  scene.lastMove = { row, col };

  return {
    createdCellsCount,
    raisedCount: createdCellsCount,
    transformed: true
  };
}


function handleDigFront(scene, row, col, piece, pieceDef) {
  const rule = pieceDef.behavior || {};
  const offsets = getOffsetsByDir(rule.offsetsByDir, piece.dir);
  const area = getAreaByOffsets(scene, row, col, offsets);

  let destroyedCellsCount = 0;

  for (const [r, c] of area) {
    if (!scene.isPlayablePoint(r, c)) continue;
    if (scene.isPiece(scene.board[r][c])) continue;
    if (scene.board[r][c] === scene.DESTROYED) continue;

    scene.board[r][c] = scene.DESTROYED;
    destroyedCellsCount += 1;
  }

  const downgrade = rule.degradeTo || 'normal';
  scene.board[row][col] = createPiece(piece.color, downgrade, null, piece.id);
  scene.lastMove = { row, col };

  return {
    destroyedCellsCount,
    dugCount: destroyedCellsCount,
    transformed: true
  };
}

function runAdvanceForPiece(scene, row, col, piece, pieceDef) {
  const behaviorType = pieceDef.behavior?.type || 'none';

  switch (behaviorType) {
    case 'move_forward':
      return handleMoveForward(scene, row, col, piece, pieceDef);

    case 'blast_area':
      return handleBlastArea(scene, row, col, piece, pieceDef);

    case 'dig_front':
      return handleDigFront(scene, row, col, piece, pieceDef);

    case 'raise_front_cells':
      return handleRaiseFrontCells(scene, row, col, piece, pieceDef);

    case 'none':
    default:
      return null;
  }
}

module.exports = {
  createPiece,
  getPieceDef,
  runAdvanceForPiece
};